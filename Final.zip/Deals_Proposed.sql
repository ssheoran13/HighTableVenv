CREATE TABLE `db`.`Deals Proposed` (
  `Deal ID` VARCHAR(45) NOT NULL,
  `Client ID` VARCHAR(45) NOT NULL,
  `idContinentals` VARCHAR(45) NOT NULL,
  `Client Name` VARCHAR(45) NOT NULL,
  `Work` VARCHAR(45) NOT NULL,
  `Min reward` VARCHAR(45) NOT NULL,
  `Client Contact` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Deal ID`),
  FOREIGN KEY (`idContinentals`) REFERENCES Continentals(`idContinentals`),
  FOREIGN KEY (`Client ID`) REFERENCES Clients(`Client ID`)
  );

insert into `Deals Proposed`  values ('54-464-6842', '51-653-5441', '90-210-0391', 'Sissie Quibell', 		'Scouting', 		'5287519400', 'squibell0@google.ru');
insert into `Deals Proposed`  values ('48-760-3928', '73-273-1440', '23-739-7547', 'Aloin Bettleson',		'Analysis', 		'1527243478', 'abettleson1@ning.com');
insert into `Deals Proposed`  values ('19-500-5029', '43-156-9047', '56-749-0064', 'Rutherford Lewinton', 	'Scouting', 		'0790555999', 'rlewinton2@dell.com');
insert into `Deals Proposed`  values ('84-576-4467', '95-089-9287', '34-940-3656', 'Chrotoem Spinley', 		'Assassination', 	'5701405370', 'cspinley3@yellowpages.com');
insert into `Deals Proposed`  values ('22-955-9158', '68-695-2293', '02-254-3961', 'Petra Cadore', 			'Cyber Security',	'5201382401', 'pcadore4@xing.com');
insert into `Deals Proposed`  values ('82-225-6120', '82-269-4585', '80-860-8003', 'Lorrie McTeer', 		'Scouting', 	 	'5925806751', 'lmcteer5@facebook.com');
insert into `Deals Proposed`  values ('13-511-7654', '25-826-8492', '88-625-5465', 'Faulkner Cowles', 		'Assassination', 	'4616671370', 'fcowles6@nasa.gov');
insert into `Deals Proposed`  values ('12-701-3472', '21-279-5768', '63-916-9347', 'Kahlil McCart', 		'Cyber Security', 	'3997256772', 'kmccart7@blogger.com');
insert into `Deals Proposed`  values ('11-512-4185', '38-762-3424', '49-082-6142', 'Yasmin Downage',		'Analysis', 		'1047683466', 'ydownage8@independent.co.uk');
insert into `Deals Proposed`  values ('62-035-2784', '78-015-1538', '41-583-5857', 'Westleigh Marushak', 	'Cyber Security', 	'1618245198', 'wmarushak9@weibo.com');
insert into `Deals Proposed`  values ('96-249-0103', '27-173-6960', '82-016-4173', 'Armstrong Lillicrop', 	'Cyber Security', 	'0945204817', 'alillicropa@ucoz.com');
insert into `Deals Proposed`  values ('20-731-8644', '95-322-3003', '03-966-6665', 'Bobbe Raffon',			'Analysis', 		'6251878169', 'braffonb@hao123.com');
insert into `Deals Proposed`  values ('85-634-6855', '33-343-4030', '65-871-0931', 'Christoforo Bute', 		'Analysis', 		'2169213031', 'cbutec@twitpic.com');
insert into `Deals Proposed`  values ('14-191-7062', '46-017-0708', '54-067-1967', 'Daven Queenborough', 	'Analysis', 		'0938690035', 'dqueenboroughd@weather.com');
insert into `Deals Proposed`  values ('76-357-9306', '82-619-6928', '65-911-4009', 'Yul Tommis', 			'Scouting', 		'8874106157', 'ytommise@usda.gov');
insert into `Deals Proposed`  values ('73-610-8510', '69-730-7055', '01-470-7364', 'Darya Posse', 			'Analysis', 		'3009324065', 'dpossef@shareasale.com');
insert into `Deals Proposed`  values ('87-841-5877', '57-909-6034', '49-835-1434', 'Norry Penlington', 		'Scouting', 		'5695723868', 'npenlingtong@aol.com');
insert into `Deals Proposed`  values ('66-794-0989', '62-320-3684', '79-260-1161', 'Nikolas Spuner', 		'Analysis', 		'1746140682', 'nspunerh@sfgate.com');
insert into `Deals Proposed`  values ('14-527-0914', '62-876-3287', '56-948-6708', 'Hashim Keeltagh', 		'Scouting', 		'2871426511', 'hkeeltaghi@webmd.com');
insert into `Deals Proposed`  values ('94-776-2317', '27-938-5294', '40-834-9661', 'Ravid Bolstridge', 		'Cyber Security', 	'5580385420', 'rbolstridgej@opensource.org');
